var fruitsList = ["Apple", "Banana", "Orange", "Kiwi"]
var orderList = []

function myFunction() {
    var text, fruit;
    fruit = document.getElementById("fruit").value;
    if (fruitsList.includes(fruit)) {
        text = fruit + " is in stock!";
        // document.getElementById("print").innerHTML = text; 
        alert(text)
    } else {
        text = fruit + " is not in stock!";
        // document.getElementById("print").innerHTML = text; 
        var order = prompt(text + " Would you like to order it in? (yes/no)")
        if (order === "yes") {
            orderList.push(fruit);
            document.getElementById("orderList").innerHTML = "The fruit you have ordered is in the following stock list: ";
            document.getElementById("print2").innerHTML = orderList;
        } else {
            alert(fruit + " not ordered.")
        }
    
    }
}

function message() {
    document.write("Thank you for placing your order. The following items have been ordered: " + orderList);
}
