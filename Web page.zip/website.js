function thankyou() {
    name = document.getElementById("fname").value;
    surname = document.getElementById("lname").value;
    mob = document.getElementById("mobile").value;
    if (name == "" || surname == "" ) {
        alert("Please fill in your name before submitting.")
    } else if (mob.length != 11 ||isNaN(mob)) {
        alert("Please enter a valid mobile number")
    } else {
        text = "Thank you for vising my page, " + name + ". I will be in touch."
        document.getElementById("form").innerHTML = text
    }

}