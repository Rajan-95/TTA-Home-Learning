function function1() {
    text1 = "Thank you for booking your session with Mr Smith, we look forward to seeing you on "
    email = " We will send an email to you confirming your weekly Ashtanga session."
    day1 = document.getElementById("day1").value;
    time1 = document.getElementById("time1").value;
    confs1 = text1 + day1 + " at " + time1 + "!" + email;
    document.getElementById("print1").innerHTML = confs1;
}

function function2() {
    text2 = "Thank you for booking your session with Mrs Johnson, we look forward to seeing you on "
    email2 = " We will send an email to you confirming your weekly Yin yoga session."
    day2 = document.getElementById("day2").value;
    time2 = document.getElementById("time2").value;
    confs2 = text2 + day2 + " at " + time2 + "!" + email2;
    document.getElementById("print2").innerHTML = confs2;
}

function function3() {
    text3 = "Thank you for booking your session with Mr Kumar, we look forward to seeing you on "
    email3 = " We will send an email to you confirming your weekly Hatha yoga session."
    day3 = document.getElementById("day3").value;
    time3 = document.getElementById("time3").value;
    confs3 = text3 + day3 + " at " + time3 + "!" + email3;
    document.write(confs3);
}